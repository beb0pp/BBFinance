import BBFinance as bb

valor = bb.get_info('PETR4.SA')
